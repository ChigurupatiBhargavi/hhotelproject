package com.hotel.hotel_booking.service;

import com.hotel.hotel_booking.model.User;
import java.util.List;

public interface UserService {

    // Create a new user
    User saveUser(User user);

    // Get all users
    List<User> getAllUsers();

    // Get user by ID
    User getUserById(Long id);

    // Get user by email
    User getUserByEmail(String email);

    // Update user by ID
    User updateUser(Long id, User userDetails);

    // Delete user by ID
    void deleteUser(Long id);
}
